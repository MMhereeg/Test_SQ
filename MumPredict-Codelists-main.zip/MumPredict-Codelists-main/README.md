# Read-codes-and-ICD-10-codes
Read codes version 2 and ICD-10 codes to identify health conditions that define pre-existing multimorbidity in pregnant women

Link to phenome definition file
https://docs.google.com/document/d/1l41IEzgHoJg0g0QGzmQmgwBit665X6Ok/edit?usp=sharing&ouid=111245565553555517672&rtpof=true&sd=true

Link to epidemiology paper
https://bmcpregnancychildbirth.biomedcentral.com/articles/10.1186/s12884-022-04442-3
